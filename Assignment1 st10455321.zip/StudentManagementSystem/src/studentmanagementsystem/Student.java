/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;
import java.util.ArrayList; 
 
 

/**
 *
 * @author RC_Student_lab
 */
public class Student extends StudentManagementSystem{

    public Student(int age) {
    }

    class name {

       

        public name() {
        }
    }
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementsystem;
import java.util.ArrayList;
import java.util.Scanner;

class student{
    String id;
    String name;
    int age;
}

/**
 *
 * @author RC_Student_lab
 */
public class StudentManagementSystem {
    static ArrayList<Student>students= new ArrayList<>();
    static Scanner scanner=new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    System.out.println("1. Capture new student");
            System.out.println("2. Search for student");
            System.out.println("3. Delete student");
            System.out.println("4. View student report");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); 

            switch (option) {
            }
                
        
        
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        
        int age = -1;
        while (age < 16) {
            System.out.print("Enter student age (must be 16 or older): ");
            if (scanner.hasNextInt()) {
                age = scanner.nextInt();
                scanner.nextLine(); // Clear the newline
                if (age < 16) {
                    System.out.println("Age must be 16 or older.");
                }
            } else {
                System.out.println("Invalid input. Please enter a numeric value for age.");
                scanner.next();
                
            }
        }

        Student newStudent = new Student(age);
        students.add(newStudent);
        System.out.println("Student added successfully!");
        
        
        System.out.print("Enter the name of the student to search for: ");
        
        
        for (Student student : students) {
            if (student.name.equalsIgnoreCase(name)){
                System.out.println("Student found: " + student);
                return;
            }
        }
        System.out.println("Student not found.");
    }

    // Method to delete a student by name
    public void deleteStudent() {
        System.out.print("Enter the name of the student to delete: ");
        String name = scanner.nextLine();
        
        for (Student student : students) {
            if (student.name.equalsIgnoreCase(name)) {
                students.remove(student);
                System.out.println("Student deleted successfully.");
                return;
            }
        }
    System.out.println("Student not found.");
    }

    // Method to generate a report of all students
    public void studentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to report.");
            return;
        }
        System.out.println("Student Report:");
        for (Student student : students) {
            System.out.println(student);
        }
    }

    // Method to exit the application
    public void exitStudentApplication() {
        System.out.println("Exiting the application. Goodbye!");
        scanner.close();
        System.exit(0);
    }
        
        
        
    }
                
                
           
            
        
 

   
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    

